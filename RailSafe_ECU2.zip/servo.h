#ifndef SERVO_H
#define SERVO_H
#include "lpc2129.h"

void servo_init(void);                   /* 50 Hz PWM on PWM2 (P0.7), starts at 0 deg */
void servo_set_target(u8 deg);
void servo_update(u32 now);              /* call often: moves 1 deg per SERVO_STEP_MS */
u8   servo_at_target(void);
u8   servo_angle(void);

#endif
