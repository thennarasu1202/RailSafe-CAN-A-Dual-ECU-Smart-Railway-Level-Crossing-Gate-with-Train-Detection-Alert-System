#ifndef SYSTEM_H
#define SYSTEM_H
/* 12 MHz crystal -> PLL x5 = 60 MHz CCLK, PCLK = CCLK/4 = 15 MHz */
#define CCLK_HZ   60000000u
#define PCLK_HZ   15000000u
void system_init(void);
#endif
