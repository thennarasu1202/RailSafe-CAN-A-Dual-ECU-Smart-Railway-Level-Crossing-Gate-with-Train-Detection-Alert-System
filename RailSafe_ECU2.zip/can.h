#ifndef CAN_H
#define CAN_H
#include "lpc2129.h"

typedef struct {
    u32 id;          /* 11-bit identifier */
    u8  dlc;         /* 0..8              */
    u8  data[8];
} CanMsg;

void can_init(void);                       /* CAN1, 1 Mbps, accept all */
int  can_send(u32 id, const u8 *data, u8 dlc);   /* 0 = queued, -1 = bus busy/no ack */
int  can_receive(CanMsg *msg);             /* 1 = frame read, 0 = none */
void can_service(void);                    /* call regularly: bus-off recovery */

#endif
