RailSafe CAN - ECU2 (Gate and Signal Unit) - LPC2129 / Keil uVision

FILES
  main.c          gate state machine, fail-safe, CAN tx/rx
  servo.c / .h    SG90 servo on PWM2, slow 1 deg steps
  signals.c / .h  red LED, green LED, buzzer
  delay.c / .h    Timer0 (ms) + Timer1 (us) delays and millis()
  can.c / can.h   CAN1 driver, 1 Mbps, polled
  system.c / .h   PLL 60 MHz, PCLK 15 MHz
  config.h        pins and timing settings (edit here)
  railsafe_can.h  CAN IDs and state values (identical in ECU1)
  lpc2129.h       register map (do not also include LPC21xx.H)

KEIL SETUP
  1. New uVision project, device NXP LPC2129, accept the Startup.s prompt.
  2. Add all .c files. Project > Options > Output > tick "Create HEX file".
  3. Build, then flash the .hex with Flash Magic.

PINS (ECU2)
  Servo signal P0.7 (PWM2) - power the servo from its own 5 V, common ground only
  Red LED P1.16, green LED P1.17, buzzer P1.18 (active high)
  CAN TD1 P0.24, RD1 P0.25 -> TJA1050 (CAN_PIN_SET in config.h)
  CAN-H/CAN-L twisted pair, 120 ohm at both ends, common ground

CALIBRATION
  SERVO_US_0DEG / SERVO_US_90DEG in config.h set the arm up/down positions.
