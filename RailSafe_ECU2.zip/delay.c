#include "delay.h"
#include "system.h"

void delay_init(void)
{
    /* Timer0: 1 ms tick (PCLK/1000) */
    T0TCR = 0x02;                         /* reset  */
    T0PR  = (PCLK_HZ / 1000u) - 1u;
    T0TCR = 0x01;                         /* run    */

    /* Timer1: 1 us tick (PCLK/1000000) */
    T1TCR = 0x02;
    T1PR  = (PCLK_HZ / 1000000u) - 1u;
    T1TCR = 0x01;
}

u32 millis(void)
{
    return T0TC;
}

void delay_us(u32 us)
{
    u32 start = T1TC;
    while ((u32)(T1TC - start) < us);
}

void delay_ms(u32 ms)
{
    while (ms--)
        delay_us(1000);
}
