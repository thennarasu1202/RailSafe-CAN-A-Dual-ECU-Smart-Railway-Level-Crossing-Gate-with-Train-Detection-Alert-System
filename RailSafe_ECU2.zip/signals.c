#include "signals.h"
#include "config.h"

static void out(u32 pin, u8 on)
{
    if (on) IO1SET = (1u << pin);
    else    IO1CLR = (1u << pin);
}

void signals_init(void)
{
    IO1DIR |= (1u << RED_PIN) | (1u << GREEN_PIN) | (1u << BUZZER_PIN);
    IO1CLR  = (1u << RED_PIN) | (1u << GREEN_PIN) | (1u << BUZZER_PIN);
}

void signal_red(u8 on)    { out(RED_PIN, on); }
void signal_green(u8 on)  { out(GREEN_PIN, on); }
void signal_buzzer(u8 on) { out(BUZZER_PIN, on); }
