/* railsafe_can.h - CAN message IDs and enums (document section 9.2). SAME FILE IN BOTH ECUs. */
#ifndef RAILSAFE_CAN_H
#define RAILSAFE_CAN_H

#define CAN_ID_TRAIN_STATUS   0x100u   /* ECU1 -> ECU2, DLC 4 */
#define CAN_ID_GATE_STATUS    0x200u   /* ECU2 -> ECU1, DLC 4 */
#define CAN_ID_EMERGENCY      0x7FFu   /* either,       DLC 1 */
#define EMERGENCY_CODE        0xFF

/* TRAIN_STATUS byte0 */
#define TRAIN_CLEAR           0
#define TRAIN_APPROACHING     1
#define TRAIN_ON_CROSSING     2
#define TRAIN_CLEARED         3

/* GATE_STATUS byte0 */
#define GATE_OPEN             0
#define GATE_CLOSING          1
#define GATE_CLOSED           2
#define GATE_OPENING          3

/* GATE_STATUS byte1 */
#define SIGNAL_GREEN          0
#define SIGNAL_RED            1

#define COMM_TIMEOUT_MS       500u     /* fail-safe timeout   */
#define TX_PERIOD_MS          100u     /* cyclic transmit     */

#endif
