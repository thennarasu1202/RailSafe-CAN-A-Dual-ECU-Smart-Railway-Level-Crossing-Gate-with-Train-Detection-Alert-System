#include "lpc2129.h"
#include "system.h"

static void pll_feed(void)
{
    PLLFEED = 0xAA;
    PLLFEED = 0x55;
}

void system_init(void)
{
    /* Disconnect + disable PLL first (in case startup code already set it) */
    PLLCON = 0x00;  pll_feed();

    /* M = 5 (MSEL = 4), P = 2 (PSEL = 01) -> Fcco = 240 MHz (valid 156..320) */
    PLLCFG = 0x24;  pll_feed();
    PLLCON = 0x01;  pll_feed();             /* enable          */
    while (!(PLLSTAT & (1u << 10)));        /* wait for lock   */
    PLLCON = 0x03;  pll_feed();             /* enable+connect  */

    /* Memory accelerator for 60 MHz */
    MAMCR  = 0;
    MAMTIM = 3;
    MAMCR  = 2;

    VPBDIV = 0;                             /* PCLK = CCLK / 4 = 15 MHz */

    /* P1.16..P1.25 are shared with the ETM trace port: make them plain GPIO */
    PINSEL2 &= ~(1u << 2);
}
