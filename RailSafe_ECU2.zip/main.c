/* ------------------------------------------------------------------
 * RailSafe CAN - ECU2 : Gate and Signal Unit (LPC2129)
 *
 *  - receives TRAIN_STATUS (0x100) and EMERGENCY (0x7FF)
 *  - APPROACHING : red flashes + buzzer, after 3 s servo lowers the gate slowly
 *  - gate closed : red steady, buzzer on
 *  - CLEARED     : servo lifts gate, green on, buzzer off
 *  - no valid frame for 500 ms (or EMERGENCY) : SAFE STATE
 *    (gate closed, red on, buzzer on)
 *  - the gate never opens while the train count is above 0
 *  - sends GATE_STATUS (0x200) every 100 ms
 * ------------------------------------------------------------------ */
#include "lpc2129.h"
#include "config.h"
#include "system.h"
#include "delay.h"
#include "can.h"
#include "servo.h"
#include "signals.h"
#include "railsafe_can.h"

/* ---- received data ---- */
static u8  train_state = TRAIN_CLEAR;
static u8  train_count = 0;
static u32 last_train_rx = 0;
static u8  alive_valid = 0;
static u8  last_alive = 0;
static u8  emerg_seen = 0;
static u32 last_emerg_rx = 0;

/* ---- gate state machine ---- */
static u8  gate = GATE_OPEN;
static u8  warn_done = 1;
static u32 warn_start = 0;

/* ---- what we are outputting (reported in GATE_STATUS) ---- */
static u8  out_signal = SIGNAL_GREEN;
static u8  out_buzzer = 0;
static u8  tx_alive = 0;

static void handle_rx(const CanMsg *m, u32 now)
{
    if (m->id == CAN_ID_TRAIN_STATUS && m->dlc >= 4) {
        /* alive counter has to change each cycle, else the frame is stale */
        if (!alive_valid || m->data[3] != last_alive) {
            alive_valid   = 1;
            last_alive    = m->data[3];
            last_train_rx = now;
            train_state   = m->data[0];
            train_count   = m->data[1];
        }
    }
    else if (m->id == CAN_ID_EMERGENCY && m->dlc >= 1 && m->data[0] == EMERGENCY_CODE) {
        emerg_seen    = 1;
        last_emerg_rx = now;
    }
}

static u8 safe_state_active(u32 now)
{
    if (TIME_ELAPSED(now, last_train_rx, COMM_TIMEOUT_MS))
        return 1;                                   /* CAN lost / stale */
    if (emerg_seen && !TIME_ELAPSED(now, last_emerg_rx, COMM_TIMEOUT_MS))
        return 1;                                   /* EMERGENCY frame  */
    return 0;
}

/* Gate may only be open when the state is CLEAR/CLEARED AND count == 0 */
static u8 want_close(u8 safe)
{
    if (safe) return 1;
    if (train_count > 0) return 1;
    if (train_state == TRAIN_CLEAR || train_state == TRAIN_CLEARED) return 0;
    return 1;                                       /* APPROACHING, ON_CROSSING, unknown */
}

static void gate_logic(u8 close_req, u8 safe, u32 now)
{
    switch (gate) {

    case GATE_OPEN:
        if (close_req) {
            gate       = GATE_CLOSING;
            warn_start = now;
            warn_done  = safe;                      /* no 3 s wait in the safe state */
        }
        break;

    case GATE_CLOSING:
        if (!close_req) {                           /* train went away during warning */
            gate = GATE_OPENING;
            servo_set_target(SERVO_OPEN_DEG);
        } else {
            if (safe || TIME_ELAPSED(now, warn_start, WARNING_DELAY_MS))
                warn_done = 1;
            if (warn_done) {
                servo_set_target(SERVO_CLOSED_DEG);
                if (servo_at_target())
                    gate = GATE_CLOSED;
            }
        }
        break;

    case GATE_CLOSED:
        if (!close_req) {
            gate = GATE_OPENING;
            servo_set_target(SERVO_OPEN_DEG);
        } else {
            servo_set_target(SERVO_CLOSED_DEG);
        }
        break;

    case GATE_OPENING:
        if (close_req) {                            /* new train: close again at once */
            gate      = GATE_CLOSING;
            warn_done = 1;
        } else if (servo_at_target()) {
            gate = GATE_OPEN;
        }
        break;

    default:
        gate = GATE_CLOSING;
        warn_done = 1;
        break;
    }
}

static void drive_outputs(u8 safe, u32 now)
{
    u8 red = 0, green = 0, buz = 0;

    switch (gate) {
    case GATE_OPEN:
        green = 1;
        break;
    case GATE_CLOSING:
        buz = 1;
        red = ((now / RED_FLASH_MS) & 1u) ? 1 : 0;  /* flashing */
        break;
    case GATE_CLOSED:
        red = 1;
        buz = 1;
        break;
    case GATE_OPENING:                              /* buzzer already off */
#if GREEN_WHEN_FULLY_OPEN
        red = 1;
#else
        green = 1;
#endif
        break;
    }

    if (safe) {                                     /* safe state overrides: steady red + buzzer */
        red = 1; green = 0; buz = 1;
    }

    signal_red(red);
    signal_green(green);
    signal_buzzer(buz);

    /* report the intended steady signal, not the flash phase */
    out_signal = (gate == GATE_OPEN || (!GREEN_WHEN_FULLY_OPEN && gate == GATE_OPENING))
                 ? SIGNAL_GREEN : SIGNAL_RED;
    if (safe) out_signal = SIGNAL_RED;
    out_buzzer = buz;
}

static void send_gate_status(void)
{
    u8 d[4];
    d[0] = gate;
    d[1] = out_signal;
    d[2] = out_buzzer;
    d[3] = tx_alive++;
    can_send(CAN_ID_GATE_STATUS, d, 4);
}

int main(void)
{
    CanMsg msg;
    u32 now, t_tx;
    u8  safe, close_req;

    system_init();
    delay_init();
    signals_init();
    servo_init();                       /* gate open (0 deg) */
    can_init();

    signal_green(1);                    /* power-up: gate open, green on */

    now = millis();
    t_tx = now;
    last_train_rx = now;                /* 500 ms grace for ECU1 to start */

    for (;;) {
        now = millis();

        can_service();
        while (can_receive(&msg))
            handle_rx(&msg, now);

        safe      = safe_state_active(now);
        close_req = want_close(safe);

        gate_logic(close_req, safe, now);
        servo_update(now);
        drive_outputs(safe, now);

        if (TIME_ELAPSED(now, t_tx, TX_PERIOD_MS)) {
            t_tx = now;
            send_gate_status();
        }
    }
}
