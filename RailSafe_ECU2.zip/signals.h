#ifndef SIGNALS_H
#define SIGNALS_H
#include "lpc2129.h"

void signals_init(void);                 /* all off */
void signal_red(u8 on);
void signal_green(u8 on);
void signal_buzzer(u8 on);

#endif
