#include "can.h"
#include "config.h"

/* C1MOD */
#define MOD_RM        (1u << 0)
/* C1CMR */
#define CMR_TR        (1u << 0)
#define CMR_AT        (1u << 1)
#define CMR_RRB       (1u << 2)
#define CMR_STB1      (1u << 5)
/* C1GSR */
#define GSR_RBS       (1u << 0)
/* C1SR */
#define SR_TBS1       (1u << 2)

/* 1 Mbps with PCLK = 15 MHz:
 *   BRP = 0 (1 tq = 66.7 ns), bit = 15 tq
 *   SYNC 1 + TSEG1 11 + TSEG2 3 -> sample point 80 %
 *   BTR: TSEG2 = 2, TSEG1 = 10, SJW = 1, BRP = 0                        */
#define CAN_BTR_1MBPS   ((2u << 20) | (10u << 16) | (1u << 14) | 0u)

void can_init(void)
{
#if (CAN_PIN_SET == 0)
    /* As written in the project document: TD1 = P0.24, RD1 = P0.25 */
    PINSEL1 &= ~((3u << 16) | (3u << 18));
    PINSEL1 |=  ((1u << 16) | (1u << 18));
#else
    /* Alternative: RD1 = P0.23, TD1 = P0.24 */
    PINSEL1 &= ~((3u << 14) | (3u << 16));
    PINSEL1 |=  ((1u << 14) | (1u << 16));
#endif

    AFMR  = 0x02;              /* acceptance filter bypass: receive every 11-bit ID */

    C1MOD = MOD_RM;            /* enter reset mode to configure */
    C1IER = 0;                 /* polled operation               */
    C1GSR = 0;                 /* clear error counters           */
    C1BTR = CAN_BTR_1MBPS;
    C1MOD = 0;                 /* normal operating mode          */
}

int can_send(u32 id, const u8 *data, u8 dlc)
{
    u32 da = 0, db = 0;
    u8  i;

    if (dlc > 8) dlc = 8;

    if (!(C1SR & SR_TBS1)) {   /* previous frame never got acknowledged (bus open?) */
        C1CMR = CMR_AT;        /* abort it so the buffer is free next time */
        return -1;
    }

    for (i = 0; i < dlc; i++) {
        if (i < 4) da |= ((u32)data[i]) << (8u * i);
        else       db |= ((u32)data[i]) << (8u * (i - 4u));
    }

    C1TFI1 = ((u32)dlc) << 16;       /* 11-bit frame, data frame */
    C1TID1 = id & 0x7FFu;
    C1TDA1 = da;
    C1TDB1 = db;
    C1CMR  = CMR_TR | CMR_STB1;      /* transmit request, buffer 1 */
    return 0;
}

int can_receive(CanMsg *msg)
{
    u32 rfs, rid, da, db;
    u8  i;

    if (!(C1GSR & GSR_RBS))
        return 0;

    rfs = C1RFS;
    rid = C1RID;
    da  = C1RDA;
    db  = C1RDB;
    C1CMR = CMR_RRB;                 /* release receive buffer */

    if (rfs & ((1u << 30) | (1u << 31)))   /* ignore RTR and 29-bit frames */
        return 0;

    msg->id  = rid & 0x7FFu;
    msg->dlc = (u8)((rfs >> 16) & 0x0Fu);
    if (msg->dlc > 8) msg->dlc = 8;

    for (i = 0; i < 8; i++) {
        if (i < 4) msg->data[i] = (u8)(da >> (8u * i));
        else       msg->data[i] = (u8)(db >> (8u * (i - 4u)));
    }
    return 1;
}

void can_service(void)
{
    /* After bus-off the controller drops into reset mode: restart it. */
    if (C1MOD & MOD_RM)
        C1MOD = 0;
}
