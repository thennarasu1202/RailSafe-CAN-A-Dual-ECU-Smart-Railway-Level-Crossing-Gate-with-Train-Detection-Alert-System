#ifndef DELAY_H
#define DELAY_H
#include "lpc2129.h"

void delay_init(void);          /* Timer0 = 1 kHz ms counter, Timer1 = 1 MHz us counter */
void delay_us(u32 us);
void delay_ms(u32 ms);
u32  millis(void);              /* free running, wraps after ~49 days (use TIME_ELAPSED) */

/* wrap-safe "has 'ms' elapsed since 'start'?" */
#define TIME_ELAPSED(now, start, ms)   ((u32)((now) - (start)) >= (u32)(ms))

#endif
