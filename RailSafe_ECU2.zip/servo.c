#include "servo.h"
#include "config.h"
#include "delay.h"

static u8  cur_deg = 0;
static u8  tgt_deg = 0;
static u32 last_step = 0;

static void servo_write(u8 deg)
{
    u32 us = SERVO_US_0DEG +
             ((u32)deg * (SERVO_US_90DEG - SERVO_US_0DEG)) / 90u;
    PWMMR2 = us;                 /* 1 us per count */
    PWMLER = (1u << 2);          /* latch MR2 at next period start */
}

void servo_init(void)
{
    PINSEL0 = (PINSEL0 & ~(3u << 14)) | (2u << 14);   /* P0.7 = PWM2 */

    PWMTCR = 0x02;               /* reset counter */
    PWMPR  = 14;                 /* 15 MHz / 15 = 1 MHz -> 1 us per tick */
    PWMMR0 = 20000;              /* 20 ms period = 50 Hz */
    PWMMCR = 0x02;               /* reset TC on MR0 match */
    cur_deg = 0;
    tgt_deg = 0;
    PWMMR2 = SERVO_US_0DEG;
    PWMLER = (1u << 0) | (1u << 2);
    PWMPCR = (1u << 10);         /* enable PWM2 output, single edge */
    PWMTCR = 0x09;               /* counter enable + PWM enable */
    last_step = millis();
}

void servo_set_target(u8 deg)
{
    tgt_deg = deg;
}

void servo_update(u32 now)
{
    if (cur_deg == tgt_deg)
        return;
    if (!TIME_ELAPSED(now, last_step, SERVO_STEP_MS))
        return;

    last_step = now;
    if (cur_deg < tgt_deg) cur_deg++;
    else                   cur_deg--;
    servo_write(cur_deg);
}

u8 servo_at_target(void) { return (cur_deg == tgt_deg) ? 1 : 0; }
u8 servo_angle(void)     { return cur_deg; }
