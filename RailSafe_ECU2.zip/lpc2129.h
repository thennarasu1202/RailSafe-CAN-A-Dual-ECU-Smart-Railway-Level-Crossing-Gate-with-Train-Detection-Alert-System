/* ------------------------------------------------------------------
 * lpc2129.h - minimal register map for LPC2129 (self-contained).
 * Do NOT also include Keil's <LPC21xx.H> in the same file (names clash).
 * ------------------------------------------------------------------ */
#ifndef LPC2129_H
#define LPC2129_H

typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned int   u32;      /* ARM7: int is 32-bit */

#define REG32(addr)  (*(volatile unsigned int *)(addr))

/* ---- System control ---- */
#define MAMCR     REG32(0xE01FC000)
#define MAMTIM    REG32(0xE01FC004)
#define PLLCON    REG32(0xE01FC080)
#define PLLCFG    REG32(0xE01FC084)
#define PLLSTAT   REG32(0xE01FC088)
#define PLLFEED   REG32(0xE01FC08C)
#define VPBDIV    REG32(0xE01FC100)

/* ---- Pin connect ---- */
#define PINSEL0   REG32(0xE002C000)
#define PINSEL1   REG32(0xE002C004)
#define PINSEL2   REG32(0xE002C014)

/* ---- GPIO ---- */
#define IO0PIN    REG32(0xE0028000)
#define IO0SET    REG32(0xE0028004)
#define IO0DIR    REG32(0xE0028008)
#define IO0CLR    REG32(0xE002800C)
#define IO1PIN    REG32(0xE0028010)
#define IO1SET    REG32(0xE0028014)
#define IO1DIR    REG32(0xE0028018)
#define IO1CLR    REG32(0xE002801C)

/* ---- Timer 0 / Timer 1 ---- */
#define T0TCR     REG32(0xE0004004)
#define T0TC      REG32(0xE0004008)
#define T0PR      REG32(0xE000400C)
#define T1TCR     REG32(0xE0008004)
#define T1TC      REG32(0xE0008008)
#define T1PR      REG32(0xE000800C)

/* ---- PWM ---- */
#define PWMTCR    REG32(0xE0014004)
#define PWMPR     REG32(0xE001400C)
#define PWMMCR    REG32(0xE0014014)
#define PWMMR0    REG32(0xE0014018)
#define PWMMR2    REG32(0xE0014020)
#define PWMPCR    REG32(0xE001404C)
#define PWMLER    REG32(0xE0014050)

/* ---- CAN acceptance filter ---- */
#define AFMR      REG32(0xE003C000)

/* ---- CAN controller 1 ---- */
#define C1MOD     REG32(0xE0044000)
#define C1CMR     REG32(0xE0044004)
#define C1GSR     REG32(0xE0044008)
#define C1ICR     REG32(0xE004400C)
#define C1IER     REG32(0xE0044010)
#define C1BTR     REG32(0xE0044014)
#define C1EWL     REG32(0xE0044018)
#define C1SR      REG32(0xE004401C)
#define C1RFS     REG32(0xE0044020)
#define C1RID     REG32(0xE0044024)
#define C1RDA     REG32(0xE0044028)
#define C1RDB     REG32(0xE004402C)
#define C1TFI1    REG32(0xE0044030)
#define C1TID1    REG32(0xE0044034)
#define C1TDA1    REG32(0xE0044038)
#define C1TDB1    REG32(0xE004403C)

#endif /* LPC2129_H */
