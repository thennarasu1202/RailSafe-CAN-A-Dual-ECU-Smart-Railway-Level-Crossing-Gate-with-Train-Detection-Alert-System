/* config.h - ECU2 (Gate and Signal Unit) */
#ifndef CONFIG_H
#define CONFIG_H

/* CAN1 pins: 0 = as in project document (TD1=P0.24, RD1=P0.25)
 *            1 = RD1=P0.23, TD1=P0.24 (use if your datasheet check says so) */
#define CAN_PIN_SET        0

/* Signals (document section 11) */
#define RED_PIN            16          /* P1.16 */
#define GREEN_PIN          17          /* P1.17 */
#define BUZZER_PIN         18          /* P1.18 */

/* Servo on PWM2 = P0.7 (document section 11) */
#define SERVO_CLOSED_DEG   90u
#define SERVO_OPEN_DEG     0u
#define SERVO_US_0DEG      1000u       /* pulse width at 0 deg  - calibrate for your servo */
#define SERVO_US_90DEG     1500u       /* pulse width at 90 deg - calibrate for your servo */
#define SERVO_STEP_MS      25u         /* 1 deg per 25 ms -> 90 deg in about 2.3 s (slow motion) */

/* Behaviour */
#define WARNING_DELAY_MS   3000u       /* flashing red + buzzer before gate moves */
#define RED_FLASH_MS       250u        /* 2 Hz flash */

/* 1 = green only after the arm is fully up (safer), red stays on while lifting.
 * 0 = green immediately when the CLEARED command arrives.                        */
#define GREEN_WHEN_FULLY_OPEN  1

#endif
