#ifndef IR_H
#define IR_H
#include "lpc2129.h"

void ir_init(void);
/* Call every IR_SAMPLE_MS. Sets *ir1 / *ir2 to 1 once when a debounced
 * "train detected" edge occurs, otherwise 0. */
void ir_update(u8 *ir1, u8 *ir2);

#endif
