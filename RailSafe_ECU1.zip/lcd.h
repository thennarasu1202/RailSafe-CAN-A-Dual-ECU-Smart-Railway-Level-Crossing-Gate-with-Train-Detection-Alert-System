#ifndef LCD_H
#define LCD_H
#include "lpc2129.h"

/* 16x2 LCD, 4-bit mode, RW tied to GND (document section 11) */
#define LCD_RS_PIN   20          /* P1.20 */
#define LCD_EN_PIN   21          /* P1.21 */
#define LCD_D4_PIN   22          /* P1.22 .. D7 = P1.25 */

void lcd_init(void);
void lcd_clear(void);
void lcd_goto(u8 row, u8 col);
void lcd_putc(char c);
void lcd_puts(const char *s);
void lcd_print_uint(u32 v);

#endif
