RailSafe CAN - ECU1 (Train Detection and Dashboard Unit) - LPC2129 / Keil uVision

FILES
  main.c          train logic, CAN tx/rx, dashboard scheduling
  lcd.c / lcd.h   16x2 LCD driver (4-bit)
  delay.c / .h    Timer0 (ms) + Timer1 (us) delays and millis()
  can.c / can.h   CAN1 driver, 1 Mbps, polled
  ir.c / ir.h     IR1/IR2 reading + debounce
  system.c / .h   PLL 60 MHz, PCLK 15 MHz
  config.h        pins and timing settings (edit here)
  railsafe_can.h  CAN IDs and state values (identical in ECU2)
  lpc2129.h       register map (do not also include LPC21xx.H)

KEIL SETUP
  1. New uVision project, device NXP LPC2129, accept the Startup.s prompt.
  2. Add all .c files. Project > Options > Output > tick "Create HEX file".
  3. In Startup.s Configuration Wizard you may leave the PLL setup off; system.c sets it.
  4. Build, then flash the .hex with Flash Magic.

PINS (ECU1)
  IR1 P1.16, IR2 P1.17 (LM393 module, output LOW = train detected; change IR_ACTIVE_LEVEL if yours is opposite)
  LCD RS P1.20, EN P1.21, D4-D7 P1.22-P1.25, RW to GND
  CAN TD1 P0.24, RD1 P0.25 -> TJA1050 (CAN_PIN_SET in config.h)
  Optional LEDs (my addition, not in the document): P0.10 train present, P0.11 ECU2 link OK
