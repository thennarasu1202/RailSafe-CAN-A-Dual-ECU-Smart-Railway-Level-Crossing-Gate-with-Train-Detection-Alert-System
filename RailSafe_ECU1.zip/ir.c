#include "ir.h"
#include "config.h"

typedef struct {
    u8 stable;      /* debounced state: 1 = train detected */
    u8 cnt;         /* consecutive samples that disagree   */
} IrChan;

static IrChan ch1, ch2;

static u8 ir_raw(u32 pin)
{
    u8 level = (IO1PIN & (1u << pin)) ? 1 : 0;
    return (level == IR_ACTIVE_LEVEL) ? 1 : 0;
}

/* returns 1 only on debounced inactive -> active edge */
static u8 ir_filter(IrChan *c, u8 raw)
{
    if (raw == c->stable) {
        c->cnt = 0;
        return 0;
    }
    c->cnt++;
    if (c->cnt >= IR_DEBOUNCE_SAMPLES) {
        c->stable = raw;
        c->cnt = 0;
        return raw;            /* 1 on rising edge, 0 on falling edge */
    }
    return 0;
}

void ir_init(void)
{
    IO1DIR &= ~((1u << IR1_PIN) | (1u << IR2_PIN));   /* inputs */
    ch1.stable = ir_raw(IR1_PIN);                     /* no false trigger at boot */
    ch2.stable = ir_raw(IR2_PIN);
    ch1.cnt = ch2.cnt = 0;
}

void ir_update(u8 *ir1, u8 *ir2)
{
    *ir1 = ir_filter(&ch1, ir_raw(IR1_PIN));
    *ir2 = ir_filter(&ch2, ir_raw(IR2_PIN));
}
