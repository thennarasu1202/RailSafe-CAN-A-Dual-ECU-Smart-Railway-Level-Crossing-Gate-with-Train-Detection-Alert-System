#include "lcd.h"
#include "delay.h"

#define LCD_RS         (1u << LCD_RS_PIN)
#define LCD_EN         (1u << LCD_EN_PIN)
#define LCD_DATA_MASK  (0x0Fu << LCD_D4_PIN)

static void lcd_nibble(u8 n)
{
    IO1CLR = LCD_DATA_MASK;
    IO1SET = ((u32)(n & 0x0Fu)) << LCD_D4_PIN;
    IO1SET = LCD_EN;
    delay_us(5);
    IO1CLR = LCD_EN;
    delay_us(50);
}

static void lcd_write(u8 v, u8 rs)
{
    if (rs) IO1SET = LCD_RS; else IO1CLR = LCD_RS;
    lcd_nibble(v >> 4);
    lcd_nibble(v & 0x0Fu);
}

static void lcd_cmd(u8 c)
{
    lcd_write(c, 0);
    if (c <= 0x03) delay_ms(2);          /* clear / home are slow */
}

void lcd_init(void)
{
    IO1DIR |= LCD_RS | LCD_EN | LCD_DATA_MASK;
    IO1CLR  = LCD_RS | LCD_EN | LCD_DATA_MASK;

    delay_ms(40);                        /* power-up wait */
    IO1CLR = LCD_RS;
    lcd_nibble(0x03);  delay_ms(5);
    lcd_nibble(0x03);  delay_us(200);
    lcd_nibble(0x03);  delay_us(200);
    lcd_nibble(0x02);                    /* switch to 4-bit */

    lcd_cmd(0x28);                       /* 4-bit, 2 lines, 5x8 */
    lcd_cmd(0x08);                       /* display off */
    lcd_cmd(0x01);                       /* clear */
    lcd_cmd(0x06);                       /* entry mode: increment */
    lcd_cmd(0x0C);                       /* display on, cursor off */
}

void lcd_clear(void)
{
    lcd_cmd(0x01);
}

void lcd_goto(u8 row, u8 col)
{
    lcd_cmd((u8)(0x80u | ((row ? 0x40u : 0x00u) + col)));
}

void lcd_putc(char c)
{
    lcd_write((u8)c, 1);
}

void lcd_puts(const char *s)
{
    while (*s)
        lcd_putc(*s++);
}

void lcd_print_uint(u32 v)
{
    char buf[11];
    u8 i = 0;

    if (v == 0) { lcd_putc('0'); return; }
    while (v) { buf[i++] = (char)('0' + (v % 10u)); v /= 10u; }
    while (i) lcd_putc(buf[--i]);
}
