/* ------------------------------------------------------------------
 * RailSafe CAN - ECU1 : Train Detection and Dashboard Unit (LPC2129)
 *
 *  - reads IR1 (entry) / IR2 (exit) every 20 ms with debouncing
 *  - keeps a train counter, derives train state
 *  - sends TRAIN_STATUS (0x100) every 100 ms
 *  - receives GATE_STATUS (0x200) from ECU2, shows "ECU2 LOST" after 500 ms
 *  - 16x2 LCD dashboard
 * ------------------------------------------------------------------ */
#include "lpc2129.h"
#include "config.h"
#include "system.h"
#include "delay.h"
#include "lcd.h"
#include "ir.h"
#include "can.h"
#include "railsafe_can.h"

/* ---- state ---- */
static u8  train_state = TRAIN_CLEAR;
static u8  train_count = 0;
static u32 last_ir2_time = 0;

static u8  gate_state = GATE_OPEN;
static u32 last_gate_rx = 0;
static u8  gate_alive_valid = 0;
static u8  gate_last_alive = 0;

static u8  tx_alive = 0;

/* dashboard text (9 chars / 7 chars so lines stay 16 wide) */
static const char * const train_txt[4] = { "CLEAR    ", "APPROACH ", "ON CROSS ", "CLEARED  " };
static const char * const gate_txt[4]  = { "OPEN   ", "CLOSING", "CLOSED ", "OPENING" };

static u8 ecu2_lost(u32 now)
{
    return TIME_ELAPSED(now, last_gate_rx, COMM_TIMEOUT_MS) ? 1 : 0;
}

static void status_leds(u32 now)
{
    if (train_count > 0) IO0SET = (1u << LED_TRAIN_PIN); else IO0CLR = (1u << LED_TRAIN_PIN);
    if (!ecu2_lost(now)) IO0SET = (1u << LED_CAN_PIN);  else IO0CLR = (1u << LED_CAN_PIN);
}

static void handle_rx(const CanMsg *m, u32 now)
{
    if (m->id == CAN_ID_GATE_STATUS && m->dlc >= 4) {
        /* alive counter must change, otherwise the frame is stale */
        if (!gate_alive_valid || m->data[3] != gate_last_alive) {
            gate_alive_valid = 1;
            gate_last_alive  = m->data[3];
            last_gate_rx     = now;
            gate_state       = (m->data[0] <= GATE_OPENING) ? m->data[0] : GATE_CLOSED;
        }
    }
}

/* train logic, runs every 20 ms */
static void train_logic(u32 now)
{
    u8 ir1, ir2;

    ir_update(&ir1, &ir2);

    if (ir1 && train_count < MAX_TRAINS)
        train_count++;

    if (ir2 && train_count > 0) {
        train_count--;
        if (train_count == 0)
            last_ir2_time = now;          /* start the 2 s safety delay */
    }

    if (train_count > 0) {
        /* ON CROSSING once ECU2 reports the gate fully closed */
        train_state = (gate_state == GATE_CLOSED && !ecu2_lost(now))
                      ? TRAIN_ON_CROSSING : TRAIN_APPROACHING;
    }
    else if (train_state == TRAIN_APPROACHING || train_state == TRAIN_ON_CROSSING) {
        if (TIME_ELAPSED(now, last_ir2_time, CLEAR_DELAY_MS))
            train_state = TRAIN_CLEARED;
    }
    else if (train_state == TRAIN_CLEARED) {
        /* go back to CLEAR when the gate is open again (or ECU2 is gone) */
        if (gate_state == GATE_OPEN || ecu2_lost(now))
            train_state = TRAIN_CLEAR;
    }
}

static void send_train_status(void)
{
    u8 d[4];
    d[0] = train_state;
    d[1] = train_count;
    d[2] = 0;                 /* distance: no ultrasonic fitted */
    d[3] = tx_alive++;
    can_send(CAN_ID_TRAIN_STATUS, d, 4);
}

/* ---- dashboard (redraw only what changed) ---- */
static u8  dash_valid = 0;
static u8  dash_state, dash_count, dash_gate, dash_lost;

static void dashboard(u32 now)
{
    u8 lost = ecu2_lost(now);

    if (dash_valid && dash_state == train_state && dash_count == train_count &&
        dash_gate == gate_state && dash_lost == lost)
        return;

    dash_valid = 1;
    dash_state = train_state;
    dash_count = train_count;
    dash_gate  = gate_state;
    dash_lost  = lost;

    /* line 1: "T:APPROACH  N:1 " */
    lcd_goto(0, 0);
    lcd_puts("T:");
    lcd_puts(train_txt[train_state & 3u]);
    lcd_puts(" N:");
    lcd_print_uint(train_count);
    lcd_putc(' ');

    /* line 2: "G:CLOSING CAN OK" or "ECU2 LOST       " */
    lcd_goto(1, 0);
    if (lost) {
        lcd_puts("ECU2 LOST       ");
    } else {
        lcd_puts("G:");
        lcd_puts(gate_txt[gate_state & 3u]);
        lcd_puts(" CAN OK");
    }
}

int main(void)
{
    CanMsg msg;
    u32 now, t_ir, t_tx, t_dash;

    system_init();
    delay_init();

    IO0DIR |= (1u << LED_TRAIN_PIN) | (1u << LED_CAN_PIN);
    IO0CLR  = (1u << LED_TRAIN_PIN) | (1u << LED_CAN_PIN);

    lcd_init();
    ir_init();
    can_init();

    lcd_goto(0, 0);  lcd_puts("RailSafe CAN    ");
    lcd_goto(1, 0);  lcd_puts("ECU1 starting...");
    delay_ms(1000);

    now = millis();
    t_ir = t_tx = t_dash = now;
    last_gate_rx  = now;                  /* 500 ms grace before "ECU2 LOST" */
    last_ir2_time = now;

    for (;;) {
        now = millis();

        can_service();
        while (can_receive(&msg))
            handle_rx(&msg, now);

        if (TIME_ELAPSED(now, t_ir, IR_SAMPLE_MS)) {
            t_ir = now;
            train_logic(now);
        }

        if (TIME_ELAPSED(now, t_tx, TX_PERIOD_MS)) {
            t_tx = now;
            send_train_status();
        }

        if (TIME_ELAPSED(now, t_dash, DASH_PERIOD_MS)) {
            t_dash = now;
            dashboard(now);
            status_leds(now);
        }
    }
}
