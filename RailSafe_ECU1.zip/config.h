/* config.h - ECU1 (Train Detection and Dashboard Unit) */
#ifndef CONFIG_H
#define CONFIG_H

/* CAN1 pins: 0 = as in project document (TD1=P0.24, RD1=P0.25)
 *            1 = RD1=P0.23, TD1=P0.24 (use if your datasheet check says so) */
#define CAN_PIN_SET        0

/* IR sensors (document section 11) */
#define IR1_PIN            16          /* P1.16  entry */
#define IR2_PIN            17          /* P1.17  exit  */
#define IR_ACTIVE_LEVEL    0           /* LM393 modules output LOW on detection */
#define IR_SAMPLE_MS       20u         /* document: read every 20 ms  */
#define IR_DEBOUNCE_SAMPLES 3u         /* stable for 3 samples = 60 ms */

/* Logic */
#define MAX_TRAINS         9u
#define CLEAR_DELAY_MS     2000u       /* 2 s safety delay after last IR2 */
#define DASH_PERIOD_MS     200u

/* Optional status LEDs (NOT in the document - my assumption, change freely) */
#define LED_TRAIN_PIN      10          /* P0.10: ON while train count > 0 */
#define LED_CAN_PIN        11          /* P0.11: ON while ECU2 is alive   */

#endif
